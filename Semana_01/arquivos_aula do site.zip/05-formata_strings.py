idade = 29

print('Minha idade é: ' + str(idade))

print('Minha idade é: {}'.format(idade))

print(f'Minha idade é: {idade}')

nome = 'Élysson MR cdoiksabncdsaicbsdaoin dsaucubsdaocpiknbsdaoiyvcsdaopikbncsdaiyvbcds'

print(f'Meu nome é {nome:.15} e eu tenho {idade:03} anos')

dinheiro = 2.598

print(f'Eu tenho {dinheiro:.2f} R$')

lista_itens = ['Garfo', 'Faca', 'copo', 'Prato']

print(f'Eu almoço com {lista_itens[0]} e {lista_itens[1]} no {lista_itens[-1]}')


print(f'Eu terei {idade + 30} anos daqui a 30 anos')
