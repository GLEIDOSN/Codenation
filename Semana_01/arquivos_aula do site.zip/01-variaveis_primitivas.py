nome = 'Élysson MR'
idade = 29
altura = 1.81
tutor = True
trabalhando = None

print(nome)
print(idade)
print(altura)
print(tutor)
print(trabalhando)


nova_idade = idade + 30

nome_cidade = nome + ' São Paulo'

print(nova_idade)
print(nome_cidade)

altura_sem_tenis = altura - 5.0

print(altura_sem_tenis)

resultado = idade + altura

print(resultado)
