# Instalação flake8: pip install flake8

import sys
import os

a = []

b = ('cdsichsdjaioujc dsacsdoaic saidojcsoadijc ssdaoicjsdaoii '
     'sojcosdijcoisadi saoidcj sodi')

idade = 20

if idade > 18:
    print("maior idade")

print(sys.argv)
print(os.times())

nome = 'Élysson MR'

print(f'Nome: {nome}')
